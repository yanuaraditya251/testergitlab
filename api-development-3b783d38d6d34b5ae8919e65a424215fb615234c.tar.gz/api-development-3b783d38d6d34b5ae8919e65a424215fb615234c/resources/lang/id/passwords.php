<?php

return [

'reset'     =>  'Kata sandi anda sudah direset.',
'sent'      =>  'Kami sudah mengirim surel yang berisi tautan untuk mereset kata sandi anda.',
'throttled' =>  'Harap tunggu sebelum mencoba lagi.',

'token'     =>  'Token pengaturan ulang kata sandi tidak sah.',
'user'      =>  'Kami tidak dapat menemukan pengguna dengan alamat surel tersebut.',

];