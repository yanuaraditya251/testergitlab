<?php

return [

'failed'    =>  'Identitas tersebut tidak cocok dengan data kami.',
'password'  =>  'Password tersebut salah.',
'throttle'  =>  'Terlalu banyak usaha masuk, silahkan coba lagi dalam :seconds detik.',

];
