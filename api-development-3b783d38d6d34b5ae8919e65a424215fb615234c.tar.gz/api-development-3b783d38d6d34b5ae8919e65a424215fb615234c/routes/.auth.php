<?php

/** @var \Laravel\Lumen\Routing\Router $router */

$router->group([ 'as' => 'auth', 'prefix' => 'auth', ], function () use ($router) {

    $router->post('/register', [ 'as' => 'register', 'uses' => 'AuthController@register', ]);
    $router->post('/login', [ 'as' => 'login', 'uses' => 'AuthController@login', ]);

    $router->group([ 'middleware' => [ 'auth', 'account.confirmed', ], ], function () use ($router) {

        $router->post('/logout', [ 'as' => 'logout', 'uses' => 'AuthController@logout', ]);
    });
});