<?php

/** @var \Laravel\Lumen\Routing\Router $router */

$router->group([ 'namespace' => 'Service', ], function () use ($router) {

    require __DIR__ . '/.auth.php';
});