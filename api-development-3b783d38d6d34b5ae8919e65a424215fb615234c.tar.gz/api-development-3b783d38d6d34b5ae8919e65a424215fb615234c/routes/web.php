<?php

/** @var \Laravel\Lumen\Routing\Router $router */