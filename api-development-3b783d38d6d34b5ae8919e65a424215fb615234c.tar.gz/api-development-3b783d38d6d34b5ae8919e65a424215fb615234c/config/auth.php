<?php

return [

    'defaults' => [ 'guard' => 'api', 'passwords' => 'default', ],
    'password_timeout' => 7200,

    'guards' => [

        'api' => [

            'driver' => 'jwt',
            'provider' => 'eloquent',
        ],

        'web' => [],
    ],

    'passwords' => [

        'default' => [

            'provider' => 'eloquent',
            'table' => 'resetters',
            'expire' => 8,
            'throttle' => 120,
        ],
    ],



    'providers' => [

        'eloquent' => [ 'driver' => 'eloquent', 'model' => App\Models\Account::class, ],
        'database' => [ 'driver' => 'database', 'table' => 'accounts', ],
    ],
];