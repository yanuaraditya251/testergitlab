<?php

namespace App\Http\Controllers\Service;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Validation\ValidationException;
use Illuminate\Auth\Events\Registered;
use Illuminate\Auth\Events\Failed;
use Illuminate\Auth\Events\Lockout;
use Illuminate\Auth\Events\Verified;
use Illuminate\Auth\Events\PasswordReset;
use Laravel\Lumen\Routing\ProvidesConvenienceMethods;
use App\Http\Controllers\Controller;
use App\Contracts\Repository\IAdminAccountRepository;
use App\Contracts\Repository\IAccountRepository;

class AuthController extends Controller
{
    use ProvidesConvenienceMethods;

    /**
     * @var \App\Contracts\Repository\IAdminAccountRepository
     */
    protected $repositoryAdminAccount;

    /**
     * @var \App\Contracts\Repository\IAccountRepository
     */
    protected $repositoryAccount;

    /**
     * @param \App\Contracts\Repository\IAdminAccountRepository $repositoryAdminAccount
     * @param \App\Contracts\Repository\IAccountRepository $repositoryAccount
     * @return void
     */
    public function __construct(IAdminAccountRepository $repositoryAdminAccount, IAccountRepository $repositoryAccount)
    {
        $this->repositoryAdminAccount = $repositoryAdminAccount;
        $this->repositoryAccount = $repositoryAccount;
    }

    /**
     * @param string $token
     * @return \Illuminate\Http\JsonResponse
     */
    protected function tokenize($token)
    {
        return responseable(
        [
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth()->factory()->getTTL() . " " . "Minutes.",

        ], null, Response::HTTP_OK);
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function register(Request $request)
    {
        try {

            event(new Registered($repository = $this->repositoryAdminAccount->register($request->input())));

            return responseable($repository, null, Response::HTTP_OK);

        } catch (ValidationException $exception) {

            return responseable($exception->errors(), null, Response::HTTP_UNPROCESSABLE_ENTITY);
        }
    }

    /**
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function login(Request $request)
    {
        $credentials = $this->validate($request,
        [
            'identity' => 'required',
            'password' => 'required',
        ]);

        if (filter_var($credentials['identity'], FILTER_VALIDATE_EMAIL)) {

            $credentials['email'] = $credentials['identity'];

        } else {

            $credentials['phone'] = $credentials['identity'];

            unset($credentials['password']);
        }

        unset($credentials['identity']);

        if (! $token = auth()->attempt($credentials)) {

            return responseable(null, "Unauthorized.", Response::HTTP_UNAUTHORIZED);
        }

        return $this->tokenize($token);
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     */
    public function logout()
    {
        auth()->logout();

        return responseable(null, "Logged out.", Response::HTTP_OK);
    }
}