<?php

namespace App\Http\Middleware;

use Illuminate\Auth\Middleware\Authorize as AuthMiddleware;

class Authorization extends AuthMiddleware
{
    //
}