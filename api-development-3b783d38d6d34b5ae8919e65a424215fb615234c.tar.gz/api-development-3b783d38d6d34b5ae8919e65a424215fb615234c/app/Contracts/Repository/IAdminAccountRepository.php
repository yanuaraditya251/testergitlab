<?php

namespace App\Contracts\Repository;

use Hundredapps\Repository\Contracts\Addable;

interface IAdminAccountRepository
{
    //
}