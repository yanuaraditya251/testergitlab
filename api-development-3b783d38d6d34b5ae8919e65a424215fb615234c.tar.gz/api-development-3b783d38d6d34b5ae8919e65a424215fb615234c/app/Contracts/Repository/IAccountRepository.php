<?php

namespace App\Contracts\Repository;

use Hundredapps\Repository\Contracts\Modifyable;

interface IAccountRepository
{
    //
}