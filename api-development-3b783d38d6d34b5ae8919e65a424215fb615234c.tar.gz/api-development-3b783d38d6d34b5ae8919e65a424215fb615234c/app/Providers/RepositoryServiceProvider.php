<?php

namespace App\Providers;

use Hundredapps\Repository\RepositoryServiceProvider as ServiceProvider;

class RepositoryServiceProvider extends ServiceProvider
{
    /**
     * @var array
     */
    protected $map =
    [
        \App\Contracts\Repository\IAdminAccountRepository::class => \App\Repositories\Eloquent\AdminAccountRepository::class,

        \App\Contracts\Repository\IAccountRepository::class => \App\Repositories\Eloquent\AccountRepository::class,
    ];
}