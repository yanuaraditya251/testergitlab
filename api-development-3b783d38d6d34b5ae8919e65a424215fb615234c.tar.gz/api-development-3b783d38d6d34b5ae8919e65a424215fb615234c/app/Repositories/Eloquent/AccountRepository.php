<?php

namespace App\Repositories\Eloquent;

use Error;
use Exception;
use Hundredapps\Repository\AbstractRepository;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Models\Account;
use App\Contracts\Repository\IAccountRepository;

class AccountRepository extends AbstractRepository implements IAccountRepository
{
    /**
     * @var array
     */
    protected $validationdata;

    /**
     * @return void
     */
    public function __construct()
    {
        $this->validationdata =
        [
            'email' => [ 'required', 'string', 'email', 'min:2', 'max:64', ],
            'phone' => [ 'required', 'string', 'regex:/^([0-9\s\-\+\(\)]*)$/', 'min:10', ],
            'password' => [ 'required', 'string', 'confirmed', ],
        ];
    }

    /**
     * @param array $data
     * @return mixed
     */
    public function modify($data)
    {
        $user = $this->user; $content = $user;
        $validation = $this->validationdata;
        $validation['email'][] = \Illuminate\Validation\Rule::unique('accounts')->ignore($content);
        $validation['phone'][] = \Illuminate\Validation\Rule::unique('accounts')->ignore($content);
        $data = Validator::make($data, $validation)->validate();

        DB::beginTransaction();

        try {

            $content = $content->update($data);

            DB::commit();

        } catch (Exception $exception) {

            DB::rollback();
        }

        return $content;
    }

    /**
     * @return mixed
     */
    public function activate()
    {
        $user = $this->user; $content = $user;

        DB::beginTransaction();

        try {

            $content->restore();

            DB::commit();

        } catch (Exception $exception) {

            DB::rollback();
        }

        return $content;
    }

    /**
     * @return mixed
     */
    public function deactivate()
    {
        $user = $this->user; $content = $user;

        DB::beginTransaction();

        try {

            $content->delete();

            DB::commit();

        } catch (Exception $exception) {

            DB::rollback();
        }

        return $content;
    }
}