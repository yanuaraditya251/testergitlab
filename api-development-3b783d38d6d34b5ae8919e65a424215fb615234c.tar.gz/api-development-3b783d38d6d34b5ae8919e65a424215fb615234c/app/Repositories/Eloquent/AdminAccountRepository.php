<?php

namespace App\Repositories\Eloquent;

use Error;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use App\Models\Account;
use App\Contracts\Repository\IAdminAccountRepository;

class AdminAccountRepository implements IAdminAccountRepository
{
    /**
     * @var array
     */
    protected $validationdata;

    /**
     * @return void
     */
    public function __construct()
    {
        $this->validationdata =
        [
            'email' => [ 'required', 'string', 'email', 'min:2', 'max:64', ],
            'phone' => [ 'required', 'string', 'regex:/^([0-9\s\-\+\(\)]*)$/', 'min:10', ],
            'password' => [ 'required', 'string', 'confirmed', ],
        ];
    }

    /**
     * @param array $data
     * @return mixed
     */
    public function register($data)
    {
        $content = null;
        $validation = $this->validationdata;
        $validation['email'][] = 'unique:' . Account::class . ',email';
        $validation['phone'][] = 'unique:' . Account::class . ',phone';
        $data = Validator::make($data, $validation)->validate();

        DB::beginTransaction();

        try {

            $data['password'] = Hash::make($data['password']);

            $content = Account::create($data);

            DB::commit();

        } catch (Exception $exception) {

            DB::rollback();
        }

        return $content;
    }
}